var app = angular.module('myapp',['ngRoute']);
app.config(function($routeProvider) {
$routeProvider.when('/view1', 
{
controller: 'Controller1',
templateUrl: 'view1.html'
})
when('/view2/:firstname/:lastname', {
controller: 'Controller2',
templateUrl: 'view2.html',
})

app.controller('Controller1', function($scope,$location){
	$scope.massage="helloo boy";
$scope.loadView2=function(){
$location.path('/view2/'+$scope.fname+'/'+$scope.lname);
};
});
app.controller('Controller2',function($scope,$routeParams,names){
	$scope.massage="hello PANKAJ";
$scope.firstname=$routeParams.firstname;
$scope.lastname=$routeParams.lastname;
  $scope.names=names;
});