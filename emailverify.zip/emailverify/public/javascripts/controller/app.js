var checkLoggedin = function($q, $timeout, $http, $location, $rootScope){
      // Initialize a new promise
      var deferred = $q.defer();
      $http.get('/users/loggedin').success(function(user){
        // Authenticated
        if(user !== '0'){
          //$timeout(deferred.resolve, 0);
        console.log("you are log in " + user);
          deferred.resolve();
             }
        // Not Authenticated
        else {
          $rootScope.message = 'You need to log in.';
          console.log("you are not log in " + user);
          deferred.reject();
         // $timeout(function(){deferred.reject();}, 0);
          $location.url('/login');
        }
      });
      return deferred.promise;
    };
app.controller("profileController",function($scope,$http,$location,$localStorage){
$scope.message="you profile page";
 $http({
		method:"get",
		url:'/users/profile',
}).then(function successCallback(response){
   //alert("okk");
$scope.profieUser=response.data;
  console.log($scope.profieUser);
}, function errorCallback(res){
	console.log("error");
});
$scope.logout=function(){
$http({
		method:"get",
		url:'/users/logout',
}).then(function successCallback(response){
	$location.path('/login');
}, function errorCallback(res){
	console.log("error");
});

}
});

app.controller("main",function($scope,$http,$location,$localStorage,$routeParams,$q,$rootScope){
		
	$scope.signup = function(){
 var uploadUrl = "/users/signup";
        var fd = new FormData();
        console.log(fd);
         var file = $scope.myfile;
        fd.append('name',$scope.name);
           fd.append('username',$scope.username);
        fd.append('email',$scope.email);
        fd.append('password',$scope.password);
		fd.append('gender',$scope.gender);
        fd.append('file', file);
   
        //JSON.stringify({name:$scope.registration.user.name,email:$scope.registration.user.email,password:$scope.registration.user.password, file:file})
        $http.post(uploadUrl,fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        }) .success(function(){
           console.log("success!!");
          $location.path("/login")
        })
        .error(function(){
          console.log("error!!");
        });
    };
//********email-verification*******
$http({
		method:"get",
		url:'/users/verify_email',
}).then(function successCallback(response){
//$scope.email=response.data;
console.log($scope.email);
}, function errorCallback(res){
	console.log("error");
});
//**************************

$scope.mylogin=function(){
		$http({
		method:"post",
		url:'/users/login',
		data:{username:$scope.username,password:$scope.password},
}).success(function(response){
           console.log("success!!");
          $location.path("/profile")
        }).error(function(response){
           console.log("error!!");
            $location.path("/login")
        });

}
//$scope.user=$localStorage.sUser

})

app.controller("listController",function($scope,$location,$http,$localStorage){
	
		$http({
		method:"get",
		url:'/users/list',
}).then(function successCallback(response){
$scope.listdata=response.data;
console.log($scope.listdata);
}, function errorCallback(res){
	console.log("error");
});

//*******
$scope.user=$localStorage.singleuser;

$scope.singleView=function(id){
	$http({
		method:"get",
		url:'/users/single/'+ id
}).then(function successCallback(response){
	$scope.singleUser=response.data;
	$localStorage.singleuser=$scope.singleUser;
	$location.path('/singleView');
},function errorCallback(res){
	console.log("error");
});

}

$scope.mydata=$localStorage.saveEdit;
//console.log($scope.mydata);
$scope.getedit=function(id){

		$http({
		method:"get",
		url:'/users/edit/' + id,
}).then(function successCallback(response){
	$scope.editData=response.data;
 $localStorage.saveEdit =$scope.editData;
   //console.log($localStorage.saveEdit)
	$location.path("/edit");
}, function errorCallback(res){
	console.log("error");
});

}

$scope.geteditsave=function(id){
$http({
		method:"put",
		url:'/users/edit/' + id,
		data:{name:$scope.mydata.name},
}).then(function successCallback(response){
	$scope.editsaveData=response.data;
  
	$location.path('/list');
}, function errorCallback(res){
	console.log("error");
});

}
$scope.deleteUser=function(id){
$http({
		method:"delete",
		url:'/users/delete/' + id,
}).then(function successCallback(response){
	//$scope.editsaveData=response.data;
  $scope.listdata.forEach(function(value,index){
  	if(value._id == id){
  	 $scope.listdata.splice(index,1);
  	}
  })
	//$location.path('/list');
}, function errorCallback(res){
	console.log("error");
});

}

})


