var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var blogSchema = new Schema({
 name: String,
 email: { type: String, required: true, unique: true },
 message:String
});



var blog = mongoose.model('blogs', blogSchema);

module.exports = blog;
