
//for save data in data base
var Usermodel = require('../model/usermodel');
module.exports.blogadd = function(req,res)
{
var blog= new Usermodel();
blog.fname=req.body.fname;
blog.email=req.body.email;
blog.content=req.body.content;

blog.save(function(err,data){
if(err)
{
console.log(err);
}
else
{
	console.log(data+'rtrtrt');
	
    res.send(data);
}
})
};
// view all user in list
module.exports.list = function(req,res){

	Usermodel.find({},function(err,blogs){
		if(err){
			res.send(err);
		}else{
			res.send(blogs);
			
		}
	});
}// in here list is send to api.js for routing
