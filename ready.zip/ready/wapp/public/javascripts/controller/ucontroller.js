
//*****************************for add in data base acts on form***************************
app.controller('cont',function($scope,$location,$http){
	$scope.addBlog=function(){
		alert("hello");
		
	$http({
		method: 'POST',
		url: '/api/addblog',
		data: {fname:$scope.fname,content:$scope.content,email:$scope.email},
	})
	
	//here http is send data to the server by post in usermodel.js
	.then(function successCallback(response) {
		if(response.data.error){
			$scope.error = response.data.error;
		}else{
			$location.path('/list');
			console.log("hi");
		}
		console.log(response+'check');
	}, function errorCallback(response) {
		console.log('error',response);
	});
	}	
});

//for view the data in list// it get the data from api.js
app.controller('viewController', function ($scope,$http)
$http({
	  method: 'GET',//if recive data then use get
	  url: '/api/list'
	  //list is the router which is given in the api
	}).then(function successCallback(response) {
	    if(response.data){
	    $scope.users = response.data;
		console.log(response.data +'users');
	    }
	}, function errorCallback(response) {
	   console.log('error',response);
	})
	)
	//it send the data in users which is get in the list