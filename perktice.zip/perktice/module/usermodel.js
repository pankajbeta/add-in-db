var mongoose = require('mongoose');
//var bcrypt   = require('bcrypt-nodejs');


var userSchema = mongoose.Schema({
        username: {type:String,unique:true},
		email: String,
        password:Number
    });
	
var User = mongoose.model('daba',userSchema);
	
module.exports = User;