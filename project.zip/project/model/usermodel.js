 var mongoose=require('mongoose');
 
 var schema=mongoose.schema;
 
 var userSchema=new schema({
 name:String,
 email:String,
 password:Number
 })
 
 var User= mongoose.model('user',userSchema);
 module.exports = user;