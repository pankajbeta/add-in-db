app.controller('cont',function($scope){
});


//it send the data to server by $http
app.controller('addcont',['$scope','$http','$location',function($scope,$http,$location){
$scope.add=function(){
$http({
	method:'POST',
	url:'/api/add',
	data:{name:$scope.name,email:$scope.email,password:$scope.password}
}).then(function successCallback(responce){
	if(responce.data.error)
	{
		$scope.error=response.data.error;
	}  
	else
	{
		$location.path('/home');
	}
},function errorCallback(response) {
console.log('error',response);
})
}
}]);