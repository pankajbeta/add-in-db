var app=angular.module('myApp',['ngRoute','ngStorage']);
app.config(['$routeProvider',function($routeProvider){
$routeProvider

.when('/add',{
templateUrl:'javascripts/view/add.html',
controller:'addcont'
})
.when('/list',{
templateUrl:'javascripts/view/list.html',
controller:'viewcontroller'
}).
when('/edit',{
templateUrl:'javascripts/view/update.html',
controller:'viewcontroller'
}).
otherwise({
redirectTo:'/view/index'
});
}]);
