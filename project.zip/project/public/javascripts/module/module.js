var app=angular.module('myApp',['ngRoute']);
app.config(['$routeProvider',function($routeProvider){
$routeProvider

.when('/add',{
controller:'addcont',
templateUrl:'javascripts/view/add.html'
}).when('/list',{
controller:'cont',
templateUrl:'javascripts/view/list.html'
}).
otherwise({
redirectTo:'/view/index'
});
}]);
