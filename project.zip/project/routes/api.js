
// these r require modules
var express = require('express');
var router = express.Router();
//var mime = require('mime-types');
//var nodemailer = require('nodemailer');
// controllers
var dbcontroller = require('../controller/dbcontroller');

router.post('/add',dbcontroller.add);
module.exports = router;