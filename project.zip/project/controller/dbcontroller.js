var Usermodel = require('../model/usermodel');//1 we require schema in 


	module.exports.add =  function(req, res) {

    var user = new Usermodel();
    user.name = req.body.name;
    user.email = req.body.email;
    user.password = req.body.password;
    
     console.log(req.body);

    Usermodel.findOne({email:req.body.email},function(err,person){
    	if(err){
    		console.log('err',err)
    	}else {
    		if(!person){
			    user.save(function (err, data) {
					if (err) {
						res.send(err);
					}else {
						console.log("success");
						//res.redirect('/login');
						res.send(data);
					}
				});
			}else{
				res.send({error:'Email is already register'});
			}
		}
	});
} 
/*module.export.login=function(req,res){

var user = new uschema();
user.name=req.body.name;
user.email=req.body.email;
user.password =req.body.password;

uschema.findOne({email:req.body.email},function(err,person){
if(err){
 console.log("error", err);
   }
else
{
  if(!person)
   {
    user.save(function(err,data)
	{
       if(err)
       res.send(err);
     }
     
    else
     {
     console.log("sucess");
     res.send(data);
      }
     });
  }
  else
   {
    res.send({error:'Email is already register'});
    }
});
}*/