var app=angular.module('myApp',['ngRoute']);
app.config(function($routeProvider){
	$routeProvider
	.when('/login',{
	templateUrl:'javascripts/view/login.html',
	controller:'cont'
	})
  .when('/add',{
	  templateUrl:'javascripts/view/add.html',
	  controller:'cont'
  })
  .when('/list',{
	  templateUrl:'javascripts/view/list.html',
	  controller:'cont'
  })
  .otherwise({
  redirectTO:'/home'});
});

