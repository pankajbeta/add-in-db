
//*****************************for add in data base acts on form***************************
app.controller('cont',function($scope,$location,$http){
	$scope.addBlog=function(){
		alert("hello");
	$http({
		method: 'POST',
		url: '/api/addblog',
		data: {fname:$scope.fname,content:$scope.content,email:$scope.email},
	})
	//here http is send data to the server by post in usermodel.js
	.then(function successCallback(response) {
		if(response.data.error){
			$scope.error = response.data.error;
		}else{
			$location.path('/list');
			console.log("hi");
		}
		console.log(response+'check');
	}, function errorCallback(response) {
		console.log('error',response);
	});
	}	
});