var express = require('express');
var router = express.Router();
var addblogcontroller = require('../controller/controller');

router.post('/addblog',addblogcontroller.blogadd);





module.exports = router;