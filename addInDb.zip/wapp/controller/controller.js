
//for save data in data base
var Usermodel = require('../model/usermodel');
module.exports.blogadd = function(req,res)
{
var blog= new Usermodel();
blog.fname=req.body.fname;
blog.email=req.body.email;
blog.content=req.body.content;

blog.save(function(err,data){
if(err)
{
console.log(err);
}
else
{
	console.log(data+'rtrtrt');
	
    res.send(data);
}
})
};
