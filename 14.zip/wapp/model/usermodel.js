
var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var userSchema = new Schema({
 fname: String,
 email: { type: String, required: true, unique: true },
content: { type: String, required: true}
});
// this is the structure for database in mongoes
//now it require in controller.js


var User = mongoose.model('User', userSchema);

module.exports = User;
