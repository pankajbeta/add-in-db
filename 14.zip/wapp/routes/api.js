var express = require('express');
var router = express.Router();
var addblogcontroller = require('../controller/controller');

router.post('/addblog',addblogcontroller.blogadd);
router.get('/list',addblogcontroller.list);
//it send the data to u controller list is(function name)addblogcontroller(variable)/list(router)



module.exports = router;