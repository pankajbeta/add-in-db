var app = angular.module("myapp",['ngRoute','ngMessages','myapp.directives','fileModel','ngStorage']);


app.config(function($routeProvider,$locationProvider){
$routeProvider.when('/login',{
	controller:'loginCtrl',
	templateUrl:'js/views/login.html'
}).when('/signup',{
	controller:'loginCtrl',
	templateUrl:'js/views/singup.html'
}).when('/view',{
controller:'loginCtrl',
  templateUrl:'js/views/view.html',
  resolve: {
    
		    logedin:checkLoggedin
	}
  
}).
otherwise({
redirectTo:'/login'
	});
$locationProvider.html5Mode({
   enabled:true,
   requireBase: false
})

});



var app = angular.module('myapp.directives', ['ngMessages']);
app.directive('compareTo', function () {
   return {
      require: "ngModel",
      scope: {
        otherModelValue: "=compareTo"
      },
      link: function(scope, element, attributes, ngModel) {

        ngModel.$validators.compareTo = function(modelValue) {
          return modelValue == scope.otherModelValue;
        };

        scope.$watch("otherModelValue", function() {
          ngModel.$validate();
        });
      }
    };
  });
var app = angular.module('fileModel', []);
app.directive('fileModel',  function ($parse) 
{
return {
    restrict: 'A',
    link: function(scope, element, attrs)
  {
        var model = $parse(attrs.fileModel);
        var modelSetter = model.assign;

        element.bind('change', function(){
            scope.$apply(function(){
                modelSetter(scope, element[0].files[0]);
            });
        });
       
     }
    };
});
var checkLoggedin = function($q, $timeout, $http, $location, $rootScope){
      // Initialize a new promise
      var deferred = $q.defer();
      $http.get('/api/logged').success(function(user){
       
        if(user !== '0'){
          //$timeout(deferred.resolve, 0);
        console.log("you are log in " + user);
          deferred.resolve();
             }
        // Not Authenticated
        else {
          $rootScope.message = 'You need to log in.';
          console.log("you are not log in " + user);
          deferred.reject();
         // $timeout(function(){deferred.reject();}, 0);
          $location.url('/login');
        }
      });
      return deferred.promise;
    };
