app.controller('loginCtrl',function($scope,$location,$http){
	$scope.login = function(){
     //console.log($scope.username);
     //console.log($scope.pass);
	$http({
		method : 'POST',
		url : "/api/login",
		data : {username:$scope.username, password:$scope.pass}
	}).then(function sucessCallback(response)
	{
		if(response.data.error)
		{
			$scope.error = response.data.error;
			console.log(scope.error);
		}
		else{
			console.log(response);
		    $scope.user = response.data;
		    console.log($scope.user);
			$location.path('/view');
		}
		//console.log(response);
	}, function errorCallback(response){
		console.log(response);
	});
	};



	$scope.singup = function(){
		$location.path('/signup');
	}

	$scope.saveuser = function(){
		var file = $scope.myFile;
 
       var uploadUrl = "api/signup";
        var fd = new FormData();
        fd.append('username',$scope.username);
        fd.append('email',$scope.email);
        fd.append('password',$scope.pass);
        fd.append('file', file);
       
        $http.post(uploadUrl,fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        }).then(function successCallback(response) {
		if(response.data.error){
			$scope.error = response.data.error;
		}else{
			
			$location.path('/login');

		}
	   //console.log(response);
	}, function errorCallback(response) {
	    console.log('error',response);
	});
    };

	
$scope.saveproduct = function(){
   $http({
   	method:'post',
   	url:'/api/product',
   	data:{pname:$scope.pname,pprice:$scope.pprice}
   }).then(function successCallback(response){
   	if(response.data.error){
   		console.log(response.data.error);
   	}
   	else {
   		console.log(response);
   	}
   }, function errorCallback(response){
   	console.log(response);
   });
};

angular.element(document).ready(function(){
		 	 	//console.log(email);
	$http({
		method: 'GET',
		url: '/api/list'
		}).then(function successCallback(response) {
		if(response.data.error){
			$scope.error = response.data.error;
		}else{
			$scope.products = response.data;
			console.log($scope.products);
          
			//$location.path('/blogadd');
		}
		
	}, function errorCallback(response) {
		console.log('error',response);
	});
});

$scope.addcart=[];
$scope.buyproduct = function(id){
	console.log(id);
   $http({
   	method:'Post',
   	url:'/api/single/'+id
   	
   }).then(function successCallback(response){
   	if(response.data.error){
   		console.log(response.data.error);
   	}
   	else {
   		
   		$scope.user = response.data
   		console.log(response.data);
        $scope.addcart.push($scope.user);
   		console.log($scope.addcart);
   	}
   }, function errorCallback(response){
   	console.log(response);
   });
};
$scope.remove=function(index)
             {
          $scope.addcart.splice(index,1);
             }

     $scope.total = function() {
    var total = 0;
    angular.forEach($scope.addcart, function(item, key){
      total += parseInt(item.pprice);
    });
    return total;
  };
});