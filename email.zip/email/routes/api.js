var express = require('express');
var router = express.Router();
var model = require('../model/usermodel');
var pmodel = require('../model/productmodel');
var multer = require('multer');
var mime = require('mime-types');
var nodemailer = require('nodemailer');
var transporter = nodemailer.createTransport('smtps://freshervishesh@gmail.com:9991281944@smtp.gmail.com');

var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;
//var bcrypt = require('bcrypt-nodejs');

var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/uploads/')
    },
    filename: function (req, file, cb) {
        console.log('file ',file);
        cb(null, Date.now()+'.'+ mime.extension(file.mimetype));
    }
});
var upload = multer({ storage: storage });



//---------------------------- Local Strategy--------------------------
passport.use(new LocalStrategy(function(username, password, done) {
  	console.log(username);
    model.findOne({ 'username': username , status:true}, function (err, person) 
   {
    		if(err){
    			console.log("error",err);
    		}
    		else {
    			
    		person.comparePassword(password, function(err, isMatch) {
            if (err) throw err;
            console.log('password:', isMatch); 
            //res.send(person);
            return done(null,person);
        });

        // 
        person.comparePassword(password, function(err, isMatch) {
            if (err) throw err;
            console.log('Password:', isMatch); 
            //res.send(person);
        });
  //  });
    			
    		}

    });
  }
));
//-----------------------------------
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

 router.get('/logged', function(req, res) {
  res.send(req.isAuthenticated() ? req.user : '0');
});


router.post('/signup',upload.single('file'), function(req, res){
   
   //console.log(req.body.email);
    model.findOne({username:req.body.username},function(err,person){
    	 var user = new model();
    

    	user.name = req.body.name;
        user.username = req.body.username;
        user.password = req.body.password;
        user.file = req.file.filename;
        user.status=false;
        user.confirm = makeid();
        var token = 'http://localhost:3000/api/verify?token=' + user.confirm;
        console.log(token);
      
           user.save(function (err, data) {
                    if (err) {
                        res.send(err);
                    }
                    else {
                    	var option = {
                    from: 'vishesh',
                    to: 'tanwar.tony136@gmail.com',       
                    //name:data.name,
                    subject : "Message Show",       
                    html:' Please confirm your email id <a href='+token+'>link</a>'
              };
              transporter.sendMail(option, function(error,info){
              	if(error){
              		return error;
              	}
              	console.log('msg send'+info.response);
              	

              });
          }
    
       res.send(data);             
             
    });
});
});

//------------------------------------------


router.post('/login',passport.authenticate('local'),function(req,res){
		console.log(req.user);
	res.send(req.user);
	//console.log(req.user);
});

router.get('/verify',function(req,res){
 console.log('verify token: ',req.query.token);
model.findOne({confirm: req.query.token }, function(err,user) {
  if (err) { return console.error(err); }
    // console.log(user);
     user.status=true;
     console.log(user.status);
      user.save(function (err) {
            if (err) return console.error(err);
            console.log('succesfully updated user');
            //console.log(data);
             res.redirect('/login');
                    });
    });
});






//==================================

passport.serializeUser(function(user, done) {
  done(null, user);
});

passport.deserializeUser(function(id, done) {
 model.findById(id, function (err, user) {
    done(err, user);
  });
});



 function makeid()
{
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    for( var i=0; i < 5; i++ )
        text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
}


//-------------------------------------------

router.post('/product', function(req, res){
   
  
    pmodel.findOne({pname:req.body.pname},function(err,person){
        var user = new pmodel();
        user.pname = req.body.pname;
        user.pprice = req.body.pprice;
             user.save(function (err, data) {
                    if (err) {
                        res.send(err);
                    }
                    else {
                      res.send(data);
                     }
                   });
           });
  });

router.get('/list', function(req, res){

 pmodel.find({},function(err,person){
      
                    if (err) {
                        res.send(err);
                    }
                    else {
                      res.send(person);
                     }
                   });
          
  });


router.post('/single/:id', function(req, res){

 pmodel.findOne({_id:req.params.id},function(err,person){
      
                    if (err) {
                        res.send(err);
                    }
                    else {
                      res.send(person);
                     }
                   });
          
  });

module.exports = router;
