
var rslt=document.getElementById("rslt")
 var strt=document.getElementById("strt")
 var stp=document.getElementById("stp")
 var rest=document.getElementById("rest")
var milisecond=0;
var seconds=0;
var minutes=0;
var hours=0;
var t;
function add(){
	milisecond++
		if(milisecond >=100){
			milisecond=0;
	 	 seconds++;
	if(seconds >=60 ){
		seconds=0;
		minutes++;
		if(minutes >=60){
			minutes=0;
			hours++;
		}
	}
	}
	
document.getElementById("rslt").innerHTML = (hours > 9 ? hours : "0" + hours) +":"+ 
 (minutes > 9 ? minutes : "0" + minutes) +":"+  (seconds > 9 ? seconds : "0" + seconds)+":"+  (milisecond > 9 ? milisecond : "0" + milisecond);
 lmp=hours +" "+ minutes+" "+seconds +" "+milisecond;
console.log(lmp);
timer()
}
function timer(){
	t =setTimeout(add,10);
}	
function resetResult(){
	milisecond=0;
	second=0;
minuts=0;
hour=0;
document.getElementById("rslt").innerHTML="00:00:00:00";
document.getElementById("dd").innerHTML ="";	
}
	function clerOut(){
		clearTimeout(t);
	}
	function lampRes(){
    document.getElementById("dd").innerHTML +=lmp + "<br/>";
	
	}
