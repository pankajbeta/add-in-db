var app =angular.module('myApp', ['ngRoute']);
app.config(function($routeProvider) {
$routeProvider.when('/view1', {
controller: 'Controller1',
templateUrl: 'view1.html'
}).
when('/view2/:firstname/:lastname', {
controller: 'Controller2',
templateUrl: 'view2.html',
}).
otherwise({
redirectTo: '/view1'
});
});
app.controller('Controller1', function($scope,$location){
	$scope.massage="hello";
$scope.loadView2=function(){
$location.path('/view2/'+$scope.firstname+'/'+$scope.lastname);
};
});
app.controller('Controller2',function($scope,$routeParams,names){
	$scope.massage="hello PANKAJ";
$scope.firstname=$routeParams.firstname;
$scope.lastname=$routeParams.lastname;
  $scope.names=names;