
app.controller('cont1',function($scope,$timeout){
$scope.msg1="this is made by pankaj";
    $timeout(function(){
        $scope.msg1="this is made by pappu";
    },2000);
});
app.controller('cont2',function($scope){
$scope.msg2="what the pappu looking for";
});