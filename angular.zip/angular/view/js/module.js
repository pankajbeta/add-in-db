var app=angular.module('myApp',['ngRoute']);
app.config(['$routeProvider',function($routeProvider){
$routeProvider.
   when('/view1',{
    templateUrl: 'js/data/view1.html',
     controller: 'cont1'
 }).	
when('/view2',{
	  templateUrl:'js/data/view2.html',
	  controller:'cont2'
	 }).
	 otherwise({
		redirectTo:'/index'
});
}]);
