var express = require('express');
var router = express.Router();
var userModel = require('../model/userModel')

/* GET home page. */
// router.get('/', function(req, res, next) {
//   res.render('index', { title: 'Express' });
// });
   router.post('/savedata', function(req,res){

   	  var  user = new userModel();
      user.name = req.body.name;
      user.uname = req.body.uname;
      user.age = req.body.age;
      user.gender = req.body.gender;
      user.hobbie = req.body.hobbie;
      user.lati = req.body.lati;
      user.logi = req.body.logi;

      userModel.findOne({uname:req.body.uname},function(err , person){
      	if(err){
      		console.log(err);
      	}
      		else 
      		{
      			if(!person){
      			user.save(function(err,data){
      				if(err){
      					console.log(err);
      				}
      				else {
      					res.send(data);
      					console.log(data);
      				}
      			});	
      			}
      		}
      	});

      });

   router.get('/showdata/:hobi',function(req,res){
   	     var hobis = req.params.hobi;
   	    //  var params = [req.params.arr].concat(req.params[0].split('/').slice(1));
   	    // var tags = req.params.tags.split(',')
   	     console.log('get hobi'+" "+ hobis);
   	     //db.inventory.find( { qty: { $in: [ 5, 15 ] } } )
 		userModel.find({'hobbie':{$in :[req.params.hobi]} },function(err,person){
 			if(err){
 				console.log(err);
 				res.send(err);
 			}
 			else {
 				console.log(person);
 				res.send(person);
 			}
 		});
   });
  

module.exports = router;