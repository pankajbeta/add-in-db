var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var userSchema = new Schema({
	name: String,
    uname: {type:String,required: true, unique:true},
    age:  {type:String,required: true},
    gender: String,
    hobbie: Array,
    lati: String,
    logi: String

});

var User = mongoose.model('user', userSchema);

module.exports = User;