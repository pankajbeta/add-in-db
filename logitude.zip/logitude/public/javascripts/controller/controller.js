app.controller('homeCtrl',function($scope,$location,$http){

$scope.save = function(){
	//alert('hello');
	var hob = $scope.hobbie.split(",");
$http({
	method:'POST',
	url:'/api/savedata',
	data:{name:$scope.name,uname:$scope.uname,age:$scope.age,gender:$scope.gender,hobbie:hob,lati:$scope.lati,logi:$scope.logi}
}).then(function successCallback(response){
           
         $scope.user = response.data;

         console.log($scope.user);
     
},function errorCallback(response){
        console.log(response.data.error);
})
};


$scope.showdata = function(){
	var hobi = $scope.hobbie.split(',');
	console.log(hobi);
	$http({
		method:'get',
		url:'/api/showdata/'+  $.param({hobi: hobi}),
		
       // params: { "hobi[]":C},
        //paramSerializer: '$httpParamSerializerJQLike',
  
	}).then(function successCallback(response){
		$scope.users = response.data;
		console.log(response);
		$location.path('/home');

	},function errorCallback(response){
		console.log(response);
	});

};
$scope.blankdata = function(){
	$scope.name  = '';
	$scope.uname = '';
	$scope.age   = '';
	$scope.gender = '';
	$scope.hobbie = '';
	$scope.lati = '';
	$scope.logi = '';
	

};
});