var app = angular.module('myApp',['ngRoute']);
app.config(function($routeProvider,$locationProvider,$httpProvider){
	$httpProvider.defaults.paramSerializer = '$httpParamSerializerJQLike';
	$routeProvider.when('/home',{
		controller:'homeCtrl',
		templateUrl:'javascripts/views/home.html'
	}).otherwise({
		redirectTo :'/home'
	});
	$locationProvider.html5Mode({
		enabled:true,
		requireBase:false
	});

})