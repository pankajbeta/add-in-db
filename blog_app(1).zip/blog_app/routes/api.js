var express = require('express');
var router = express.Router();
//var session = require('express-session');
var multer = require('multer');
var mime = require('mime-types');
var favicon = require('serve-favicon');
var nodemailer = require('nodemailer');

//****************** controllers************************//

var userController = require('../controller/usercontroller');
var usercontact = require('../controller/contactcontroller');
var userblog = require('../controller/addblogcontroller');


//***************uploadsimage in signup****************//
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/uploads/')
    },
    filename: function (req, file, cb) {
    	console.log('file ',file);
        cb(null, Date.now()+'.'+ mime.extension(file.mimetype));
    }
});
var upload = multer({ storage: storage });


//************************add image in addedblog ******************************************//
var blogupload = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/uploadsblog/')
    },
    filename: function (req, file, cb) {
    	console.log('file ',file);
        cb(null, Date.now()+'.'+ mime.extension(file.mimetype));
    }
});
var uploadblog = multer({ storage: blogupload });


// routes 
router.post('/login',userController.login);


router.post('/signup', upload.single('file'), userController.signup);


router.post('/addblog', uploadblog.single('file'), userblog.addblog);


router.get('/home', userblog.home);


router.get('/listblog', userblog.listblog);
router.delete('/delete/:id', userblog.delete);
router.get('/blogview/:id', userblog.viewblog);
router.get('/editblog/:id',userblog.editblog);
router.post('/editblog/:id',userblog.saveEditblog);


router.get('/profile', userController.profile);


router.post('/contact',usercontact.contact);








module.exports = router;