//model
var Usermodel = require('../model/signupmodel');

//************************************ sign up user*******************************************//
module.exports.signup =  function(req, res) 
{
    var user = new Usermodel();
    user.name = req.body.name;
    user.email = req.body.email;
    user.password = req.body.password;
	user.file = req.file.filename;
	
    console.log(req.body);
    user.save(function (err, data) {
					if (err) 
					{
						//console.log(err);
						res.send(err);
					}
					else
						{
						//console.log("valueEnterd");
						res.send(data);
					    }
			
		})
	};
	
//****************** login user******************//
module.exports.login =  function(req, res) 
{
var email = req.body.email;
var password =req.body.password;

Usermodel.findOne({email:email},function(err,person){
	if(err)
	{ 
        //console.log(err);
		res.send(err);
	}
	else
	{
	      if(person)
		  {
			  if(person.password == password)
			  {
				  res.send({status:true,data:person});
			  }
			  else
			  {
				  //console.log("Invalid password");
			  res.send({error:'Invalid password'});
			  }
			  
		  }
		  
		  else
		  {
			  //console.log("Invalid Email");
			  res.send({error:'Email is invalid'});
		  }
	}
});
}


//********************profile************************//
module.exports.profile = function(req, res)
{
Usermodel.find({},function(err, data)
{
	if(err)
	{ 
        //console.log(err);
		res.send(err);
		
	}
	else
	{
		//console.log(data);
		res.send(data);
	
	}
})	
};
