var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var userSchema = new Schema({
 name: {type:String},
 email: { type: String, required: true, unique: true },
 password: { type: Number, required: true},
 file: String
 //repassword: { type: Number, required: true}
});



var User = mongoose.model('signup', userSchema);

module.exports = User;
