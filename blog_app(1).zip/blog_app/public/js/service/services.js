//************************service for authentication ****************//

app.factory("auth" , function($http, $localStorage ,$location){
	var userAuth;
     return {
      setTlogIn: function(email, password) {
	$http({
		  method: 'POST',
		  url: '/api/login',
		  data: {email:email, password:password},
		}).then(function successCallback(response) {
			userAuth =response.data;
			     //userAuth1 =response.data1;
			console.log(userAuth);
			      //console.log(userAuth);
			$localStorage.myuserdata=userAuth;
			       // console.log($localStorage.myuserdata);
			console.log($localStorage.myuserdata);
		////*if($localStorage.myuserdata.data.email == email){
            //// alert("valid user");
					$location.path('/home');
				////}
			//// else{
				////alert('not valid');
				//// $location.path('/login');
			/////}*
			
	      // console.log(response);
		}, function errorCallback(response) {
		    console.log('error',response);
		});
        },
        isLoggin:function(){
        	return (userAuth)? userAuth=true :  userAuth=false ;
        },
        isLogOut:function(){
        	return userAuth= false;
        }
    };

});
