
//this schema is used to for edit and update

var mongoose=require('mongoose');
var Schema = mongoose.Schema;
var blogSchema=new Schema({
tile:String,
content:String,
})


 var blog = mongoose.model('blogs',blogSchema);
 module.exports =blog;