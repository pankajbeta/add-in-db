var mongoose = require('mongoose');
//var bcrypt   = require('bcrypt-nodejs');


var userSchema = mongoose.Schema({
        username: String,
		email: String,
        password: Number
    });
	
var User = mongoose.model('register',userSchema);
	
module.exports = User;