var express = require('express');
var router = express.Router();
var Usermodel = require('../module/usermodel');
var passport = require('passport');
var LocalStrategy=require("passport-local").Strategy;
//var flash    = require('connect-flash');

/* GET home page. */
router.get('/', isAuthincation,function(req, res, next) {
  res.render('index', { title: 'Express' });
});

function isAuthincation(req,res,next){
	if(req.isAuthenticated()){
		return next();
	}
	else {
		res.redirect('/login');
}
}
router.get('/login', function(req, res, next) {
  res.render('login', { title: 'login' });
});

router.get('/signup', function(req, res, next) {
  res.render('sign', { title: 'sign' });
});

router.get('/profile', isAuthincation,function(req, res, next) {
  res.render('profile', { data:req.user });
});

router.post('/signup',function(req,res,next){
	
	var user = new Usermodel();
	user.username = req.body.username;
	user.email = req.body.email;
	user.password = req.body.password;
Usermodel.findOne({email:req.body.email},function(err,person){
	if(err){
		res.send(err);
	}
	else {
		if(!person)
		{
			user.save(function(err,data){
			if(err)
			{
				console.log(err);
			}
			else
			{
				//console.log(data);
				//res.send(data);
				res.redirect('/login');
			}
			})
		}else{
			console.log("user already registerd");
		}
	}
});
	});
	
router.post('/login', passport.authenticate('local',{successRedirect : '/profile',failureRedirect : '/login'}),
		function(req, res, next) {
	    res.redirect('/'); 
		
});
	
	/*var username = req.body.username;
	var password = req.body.password;
	
   Usermodel.findOne({username:username},function(err,person){
	if(err)
	{ 
        //console.log(err);
		res.send(err);
	}
	else
	{
	      if(person)
		  {
			  if(person.password == password)
			  {
				  //res.send({status:true,data:person});
                  res.redirect('/profile');				
				//console.log(data);
			  }
			  else
			  {
				console.log("Invalid password");
			  res.send({error:'Invalid password'});
			  }
			  
		  }
		  
		  else
		  {
			console.log("Invalid Email");
			  res.send({error:'Email is invalid'});
		  }
	}
});*/

	//**serializer&deserializer
	 passport.serializeUser(function(user, done) {
        done(null, user.id);
    });

    passport.deserializeUser(function(id, done) {
        Usermodel.findById(id, function(err, user) {
            done(err, user);
        });
    });

//**checkeing**************
passport.use(new LocalStrategy(function(username,password,done){
	Usermodel.findOne({username:username},function(err,user){
		if(err){
		return done(err);
		}
		if (!user) 
		    {
			return done(null, false);
			}
		if(user.password != password)
			{
				return done(null, false);
			}
			return done(null, user);
	});	
}));

router.get('/logout', function(req, res) {
		req.logout();
		res.redirect('/');
	});
module.exports = router;
