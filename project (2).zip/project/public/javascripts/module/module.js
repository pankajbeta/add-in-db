var app=angular.module('myApp',['ngRoute']);
app.config(['$routeProvider',function($routeProvider){
$routeProvider

.when('/add',{
templateUrl:'javascripts/view/add.html',
controller:'addcont'
})
.when('/list',{
templateUrl:'javascripts/view/list.html',
controller:'viewcontroller'
}).
otherwise({
redirectTo:'/view/index'
});
}]);
