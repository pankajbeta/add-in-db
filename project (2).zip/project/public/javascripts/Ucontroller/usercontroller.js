app.controller('cont',function($scope){
});


//1it send the data to server by $http and do the action on user form
//1for add data fom add.html to data base*************
app.controller('addcont',function($scope,$location,$http)
{
	
	$scope.signUpUser=function(){
 
	$http({
		method: 'POST',
		url: '/api/add',
		data: {name:$scope.name,email:$scope.email, password:$scope.password}
	})
	.then(function successCallback(response) {
		if(response.data.error){
			$scope.error = response.data.error;
		}else{
			$location.path('/list');
			//console.log("hi");
		}
		console.log(response);
	}, function errorCallback(error) {
		console.log('error',error);
	});
	
}
});

//2*********************view all data from data base in list**************
//in here it get the data by get method and sed it by users
app.controller('viewcontroller', function ($scope,$http) {
$http({
	method:'GET',
	url: '/api/list'
    })
	
	.then(function successCallback(response) {
	    if(response.data){
	    $scope.users = response.data;
		console.log(response.data +'users');
	    }
	}, function errorCallback(response) {
	   console.log('error',response);
})

//3*********************for delete data from list**************
// it id done in view controller controller
$scope.removePost = function(id) {
        $http({ 
                url: 'api/delete/'+ id ,
                method: 'delete'
        }).then(function(res) {
            $scope.users.forEach(function(value,index){
              if(value._id == id){
               $scope.users.splice(index,1);

              }
            })
        }, function(error) {
            console.log(error);
        });
    };
	$scope.viewUser= function(){
		$location.path('/add')
	}
});