var Usermodel = require('../model/usermodel');//1 we require schema in 

//1*****************for add data in data base ******************
	module.exports.add =  function(req, res) {

    var user = new Usermodel();
    user.name = req.body.name;
    user.email = req.body.email;
    user.password = req.body.password;
    
     console.log(req.body);
           user.save(function (err, data) {
					if (err) {
						res.send(err);
					}else {

						//res.redirect('/login');
						res.send(data);
					    console.log(data);
					}
				});
			
	}

/*module.export.login=function(req,res){

var user = new uschema();
user.name=req.body.name;
user.email=req.body.email;
user.password =req.body.password;

uschema.findOne({email:req.body.email},function(err,person){
if(err){
 console.log("error", err);
   }
else
{
  if(!person)
   {
    user.save(function(err,data)
	{
       if(err)
       res.send(err);
     }
     
    else
     {
     console.log("sucess");
     res.send(data);
      }
     });
  }
  else
   {
    res.send({error:'Email is already register'});
    }
});
}*/

//2****************it send data form database to list******
module.exports.listuser=function(req, res){
	Usermodel.find({},function(err,blogs){
		if(err){
			res.send(err);
		}
		else{
			res.send(blogs);
			console.log(blogs);
		}
		
	});
}

//3***************for delete in list*********************
  module.exports.removeData=function (req, res){
	console.log(req.params.id);
	 var blog = new Usermodel();
  Usermodel.findById(req.params.id, function ( err, blog ){//usermodel is schema
    blog.remove(function (err, blog ){
      //res.redirect( '/list' );
      res.send(blog)
      console.log("delete");
    });
  });
}