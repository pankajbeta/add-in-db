
// these r require modules
var express = require('express');
var router = express.Router();
//var mime = require('mime-types');
//var nodemailer = require('nodemailer');
// controllers
var usercontroller = require('../controller/dbcontroller');

router.post('/add',usercontroller.add);
router.get('/list',usercontroller.listuser);
router.delete('/delete/:id',usercontroller.removeData);
module.exports = router;