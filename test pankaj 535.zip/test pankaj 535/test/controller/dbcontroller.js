var Usermodel = require('../model/usermodel');//1 we require schema in 
var Usermodell =  require('../model/usermodell');
//1*****************for add data in data base ******************
	module.exports.add =  function(req, res) { // in  here req is get and res is for send

    var user = new Usermodel();
    user.name = req.body.name;
    user.email = req.body.email;
    user.password = req.body.password;
    console.log(req.body);
    user.save(function (err, data) {
					if (err) {
						res.send(err);
					}else {

						//res.redirect('/login');
						res.send(data);
					    console.log(data);
					}
				});
			
	}


module.exports.rows =  function(req, res) { // in  here req is get and res is for send

    var user = new Usermodell();
    user.title = req.body.title;
    user.seat = req.body.seat;
    console.log(req.body);
    user.save(function (err, data) {
					if (err) {
						res.send(err);
					}else {

						//res.redirect('/login');
						res.send(data);
					    console.log(data);
					}
				});
			
	}



//2****************it send data form database to list******
module.exports.listuser=function(req, res){
	Usermodell.find({},function(err,blogs){
		if(err){
			res.send(err);
		}
		else{
			res.send(blogs);
			console.log(blogs);
		}
		
	});
}

//3***************for delete in list*********************
  module.exports.removeData=function (req, res){
	console.log(req.params.id);
	 var blog = new Usermodel();
  Usermodell.findById(req.params.id, function ( err, blog ){//usermodel is schema
    blog.remove(function (err, blog ){
      //res.redirect( '/list' );
      res.send(blog)
      console.log("delete");
    });
  });
}
//4*************************FOR UPDATE 1 EDIT*******************
//edit
module.exports.edit=function (req,res){
	console.log(req.params.id);
Usermodell.findOne({_id:req.params.id},function(err,docs){
	if(err){
		console.log('err',err)
	}
	
		
			else{
				//console.log(docs.data);
				res.send(docs);
			}
		
	
	});
}
//update save
module.exports.editsave =  function(req, res) {
console.log(req.params.id);
   // var user = new Usermodel();  
Usermodell.findOne({_id:req.params.id},function(err,docs){  
  docs.title = req.body.title;
  docs.seat = req.body.seat; 
  if(err){
	  console.log(err);
	  } 
	  else {
	  if(docs){
           docs.save(function (err, data) {
					if (err) {
						res.send(err);
					}else {

						//res.redirect('/login');
						res.send(data);
					    console.log(data);
					}
				});
	  }
			
	}

});
}


//5 login*******************
module.exports.login = function(req,res){//controller
	var email=req.body.email;
	var password=req.body.password;
	 
	Usermodel.findOne({email:email},function(err,person){
    	if(err){
    		console.log('err',err)
    	}else {
    		if(person){
    			if(person.password==password){
    				res.send(person);
    			}else{
    				res.send({error:'Incorrect Password'});
    			}
    		}else{
    			res.send({error:'Email is not Register'});
    		}
    	}
    });
}
